package Aplikazioa;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Aplikazioa {
    
    static ArrayList<XakePieza> piezak  = new ArrayList<>(32);
    static Scanner sc = new Scanner(System.in);
    
    public static void main(String args[]) throws IOException, ClassNotFoundException{
        
        File fitxategia =new File("jolasaldia.dat");
        if(fitxategia.createNewFile()){
                    
            XakePieza partida = new XakePieza();
            piezak =  partida.hasieratu();
            
        }
        else{
            
            FileInputStream fis = new FileInputStream("jolasaldia.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            int kopurua =0;
            
            try{
            
                XakePieza pieza;
                
                while((pieza = (XakePieza) ois.readObject()) != null){
            
                    System.out.println(pieza.getIzena() + " " + pieza.getKolorea());
                    piezak.add(pieza);
                    kopurua++;
            
                }
            
            }
            catch (IOException ioe){
                
                System.out.println(kopurua + " pieza daude fitxategian.");
//                System.out.println("errorea:" + ioe.getMessage());
                
            }
            finally{
                
                ois.close();
                
            }
//            XakePieza pieza;
//
//            for(int i=0; i<32;i++){
//                
//                pieza = (XakePieza) ois.readObject();
//                piezak.add(pieza);
//                
//            }
//          
//            ois.close();
         
        }
        menua();
        bistaratu();
        idatzi();
//        
    }
    static void menua(){
        
        int auk = aukeraketa();
        
        while(auk==1){
            
            System.out.print("Sartu piezaren informazioa:\nPieza mota: ");
            String izena = sc.next();
            System.out.print("Kolorea (txuria edo beltza): ");
            String kolorea = sc.next();
            System.out.print("X koordenatua (karakterea): ");
            char x = sc.next().charAt(0); 
            System.out.print("Y koordenatua (zenbakia): ");
            int y = sc.nextInt();
            
            desplazamendua(izena, kolorea, x, y);
            auk = aukeraketa();
        }
        
    }
    
    private static int aukeraketa(){
        
        System.out.print("\n\nPieza bat mugitu nahi duzu?:\n\t1 - BAI."
                + "\n\t0 - EZ.\n\n\t\t");
        int aux = sc.nextInt();
        
        return aux;
        
    }
    
    static void desplazamendua(String izena, String kolorea, char x, int y){
        
        for(int i=0;i<32;i++){
            
            if(izena.compareTo(piezak.get(i).getIzena())==0 && kolorea.compareTo(piezak.get(i).getKolorea())==0){
                
                System.out.println(piezak.get(i).getIzena() + " " + piezak.get(i).getKolorea());
                piezak.get(i).posizioa();
                piezak.get(i).mugitu(x, y);
                System.out.println("Berriztapena:");
                System.out.println(piezak.get(i).getIzena() + " " + piezak.get(i).getKolorea());
                piezak.get(i).posizioa();
                break;
                
            }
            
        }
        
    }
    static void bistaratu(){
        
        System.out.println("Piezen kokapena:");
            
        
        for(int i=0;i<32;i++){
            
            System.out.println(piezak.get(i).getIzena() + " " + piezak.get(i).getKolorea() + " [" + piezak.get(i).x + "," + piezak.get(i).y + "]");
                
        }
        
    }
    static void idatzi() throws FileNotFoundException, IOException{
        
        DataOutputStream fos = new DataOutputStream(new FileOutputStream("jolasaldia.dat"));
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        
        for(int i=0; i<piezak.size(); i++){
            
            oos.writeObject((XakePieza) piezak.get(i));
            
        }
        oos.close();
        fos.close();
    }
}
