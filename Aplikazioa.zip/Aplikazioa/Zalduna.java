package Aplikazioa;


public class Zalduna extends XakePieza{
    
    public Zalduna(String kolorea, char x, int y){
        
        izena="zalduna";
        this.kolorea=kolorea;
        ikurraEsleitu();
        this.x=x;
        this.y=y;       
        
    }
    
    
    public void mugitu(char x, int y){
        
        int j, k;
        
        j=x-this.x;
        if(j<0){
            
            j=-1*j;
        }
        k=y-this.y;
        if(k<0){
            
            k=-1*k;
            
        }
        
        if((j==2 && k==1) || (j==1 && k==2)){
            
            super.mugitu(x, y);
            
        }
        else{
            
            System.out.println("Mugimendua ez dago baimenduta.");
            System.out.println("Bakarrik bi bertikalean eta bat horizontalean edo alderantziz mugitu daiteke.");
            
        }
        
    }
    
}
