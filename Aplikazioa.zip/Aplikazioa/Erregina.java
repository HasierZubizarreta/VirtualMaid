package Aplikazioa;


public class Erregina extends XakePieza{
    
    public Erregina(String kolorea, char x, int y){
        
        izena="erregina";
        this.kolorea=kolorea;
        ikurraEsleitu();
        this.x=x;
        this.y=y;       
        
    }
    
    public void mugitu(char x, int y){
        
        super.mugitu(x, y);
        
    }
    
}
