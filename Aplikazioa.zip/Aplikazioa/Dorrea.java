package Aplikazioa;


public class Dorrea extends XakePieza{
    
    public Dorrea(String kolorea, char x, int y){
        
        izena="dorrea";
        this.kolorea=kolorea;
        ikurraEsleitu();
        this.x=x;
        this.y=y;       
        
    }
    
    public void mugitu(char x, int y){
        
        int j, k;
        
        j=x-this.x;
        if(j<0){
            
            j=-1*j;
        }
        k=y-this.y;
        if(k<0){
            
            k=-1*k;
            
        }
        
        if(j==0 || k==0){
            
            super.mugitu(x, y);
            
        }
        else{
            
            System.out.println("Mugimendua ez dago baimenduta.");
            System.out.println("Bakarrik horizoantalean edo bertikalean mugitu daiteke.");
            
        }
        
    }
    
}
