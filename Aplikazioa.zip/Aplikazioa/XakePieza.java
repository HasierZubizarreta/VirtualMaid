package Aplikazioa;

import java.io.Serializable;
import java.util.ArrayList;


class XakePieza implements Serializable{
    
    protected String izena;
    protected String kolorea;
    protected char ikurra;
    protected char x;
    protected int y;
    
    protected void mugitu(char x, int y){
        
        this.x=x;
        this.y=y;
        
    };
    
    public String getIzena() {
        return izena;
    }

    public String getKolorea() {
        return kolorea;
    }
    
    public void ikurraEsleitu(){
        if(kolorea.compareToIgnoreCase("txuria")==0){
            if(izena.compareToIgnoreCase("erregea")==0){
            
                this.ikurra=0x2654;
            
            }
            
            if(izena.compareToIgnoreCase("erregina")==0){
                
                this.ikurra=0x2655;
            
            }
            
            if(izena.compareToIgnoreCase("dorrea")==0){
            
                this.ikurra=0x2656;
            
            }
            
            if(izena.compareToIgnoreCase("alfila")==0){
            
                this.ikurra=0x2657;
            
            }
            
            if(izena.compareToIgnoreCase("zalduna")==0){
            
                this.ikurra=0x2658;
            
            }
            
            if(izena.compareToIgnoreCase("peoia")==0){
            
                this.ikurra=0x2659;
            
            }
            
        }
        else{
            
            if(izena.compareToIgnoreCase("erregea")==0){
            
                this.ikurra=0x265A;
            
            }
            
            if(izena.compareToIgnoreCase("erregina")==0){
            
                this.ikurra=0x265B;
            
            }
            
            if(izena.compareToIgnoreCase("dorrea")==0){
                
                this.ikurra=0x265C;
            
            }
            
            if(izena.compareToIgnoreCase("alfila")==0){
            
                this.ikurra=0x265D;
            
            }
            
            if(izena.compareToIgnoreCase("zalduna")==0){
            
                this.ikurra=0x265E;
            
            }
            
            if(izena.compareToIgnoreCase("peoia")==0){
            
                this.ikurra=0x265F;
            
            }
            
        }
        //System.out.println(izena + " " + kolorea + " " + String.valueOf(x) + String.valueOf(y) + " " + String.valueOf(ikurra));
        
    }
    public void posizioa(){
        
        System.out.println("Posizioa:" + String.valueOf(x) + String.valueOf(y));
        
    }
    public ArrayList<XakePieza> hasieratu(){
        
        ArrayList<XakePieza> piezak  = new ArrayList<>(32);
        
        for(int i=0;i<8;i++){

                for(char j='a';j<'i';j++){

                    
                    if(1<i && i<6){
                        continue;
                    }
                    else{
                        
                        piezak.add(setPieza(i,j));
                        
                        
                    }
                }
                
            }
        return piezak;
    }   
    public XakePieza setPieza(int i, char j){
        
        XakePieza pieza = null;
        
        if(i<1){   
            
            switch (j) {
                case 'a':
                case 'h':
                    {
                        pieza = new Dorrea("txuria", j, i+1);
                        break;
                    }
                case 'b':
                case 'g':
                    {
                        pieza = new Zalduna("txuria", j, i+1);
                        break;
                    }
                case 'c':
                case 'f':
                    {
                        pieza = new Alfila("txuria", j, i+1);
                        break;
                    }
                case 'd':
                    {
                        pieza = new Erregina("txuria", j, i+1);
                        break;
                    }
                case 'e':
                    {
                        pieza = new Erregea("txuria", j, i+1);
                        break;
                    }
                
            }
              
        }
        else if(i==1){
                
                pieza = new Peoia("txuria", j, i+1);
                              
            }
        else if(i==6){
                
                pieza = new Peoia("beltza", j, i+1);
                                       
        }
        else if(5<i){

            switch (j) {
                case 'a':
                case 'h':
                    {
                        pieza = new Dorrea("beltza", j, i+1);
                        break;
                    }
                case 'b':
                case 'g':
                    {
                        pieza = new Zalduna("beltza", j, i+1);
                        break;
                    }
                case 'c':
                case 'f':
                    {
                        pieza = new Alfila("beltza", j, i+1);
                        break;
                    }
                case 'd':
                    {
                        pieza = new Erregina("beltza", j, i+1);
                        break;
                    }
                case 'e':
                    {
                        pieza = new Erregea("beltza", j, i+1);
                        break;
                    }
                
            }
            
        }
     
    return pieza;
}

}