package Aplikazioa;


public class Alfila extends XakePieza{
    
    public Alfila(String kolorea, char x, int y){
        
        izena="alfila";
        this.kolorea=kolorea;
        ikurraEsleitu();
        this.x=x;
        this.y=y;       
        
    }
    
    public void mugitu(char x, int y){
        
        int j, k;
        
        j=x-this.x;
        if(j<0){
            
            j=-1*j;
        }
        k=y-this.y;
        if(k<0){
            
            k=-1*k;
            
        }
        
        if(j<2 == k<2){
            
            super.mugitu(x, y);
            
        }
        else{
            
            System.out.println("Mugimendua ez dago baimenduta.");
            System.out.println("Bakarrik diagonalean mugitu daiteke.");
            
        }
        
    }
    
}
